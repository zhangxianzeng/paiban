package org.optaplanner.examples.nurserostering.domain.pattern;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import org.optaplanner.examples.nurserostering.domain.ShiftType;

@XStreamAlias("TakeTurnsShiftByShiftPattern2")
public class TakeTurnsShiftByShiftPattern2 extends Pattern {

	   private ShiftType firstShiftType;
	    private ShiftType secondShiftType;
	    private ShiftType thirdShiftType;
	    

	    public ShiftType getfirstShiftType() {
	        return firstShiftType;
	    }

	    public void setfirstShiftType(ShiftType firstShiftType) {
	        this.firstShiftType = firstShiftType;
	    }

	    public ShiftType getSecondShiftType() {
	        return secondShiftType;
	    }

	    public void setSecondShiftType(ShiftType secondShiftType) {
	        this.secondShiftType = secondShiftType;
	    }

	    public ShiftType getThirdShiftType() {
	        return thirdShiftType;
	    }

	    public void setThirdShiftType(ShiftType thirdShiftType) {
	        this.thirdShiftType = thirdShiftType;
	    }

	    @Override
	    public String toString() {
	        return "Work pattern: " + firstShiftType + ", " + secondShiftType + ", " + thirdShiftType ;
	    }
}
