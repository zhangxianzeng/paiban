package org.optaplanner.examples.nurserostering.domain.pattern;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import org.optaplanner.examples.nurserostering.domain.ShiftType;

@XStreamAlias("ShiftAssignedOnlyforManPattern")
public class ShiftAssignedOnlyforManPattern extends Pattern{
	
	private ShiftType dayShiftType; 

    public ShiftType getDayShiftType() {
        return dayShiftType;
    }

    public void setDayShiftType(ShiftType dayShiftType) {
        this.dayShiftType = dayShiftType;
    }

    @Override
    public String toString() {
        return "Work " + dayShiftType + " type";
    }


}
