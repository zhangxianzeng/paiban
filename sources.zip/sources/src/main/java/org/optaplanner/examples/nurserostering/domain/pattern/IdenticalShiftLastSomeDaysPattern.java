package org.optaplanner.examples.nurserostering.domain.pattern;


import com.thoughtworks.xstream.annotations.XStreamAlias;
import org.optaplanner.examples.nurserostering.domain.ShiftType;

@XStreamAlias("IdenticalShiftLastSomeDaysPattern")
public class IdenticalShiftLastSomeDaysPattern extends Pattern{
	
	private ShiftType dayShiftType; 

    private int ShiftLastLength;

    public ShiftType getDayShiftType() {
        return dayShiftType;
    }

    public void setDayShiftType(ShiftType dayShiftType) {
        this.dayShiftType = dayShiftType;
    }

    public int getShiftLastLength() {
        return ShiftLastLength;
    }

    public void setShiftLastLength(int ShiftLastLength) {
        this.ShiftLastLength = ShiftLastLength;
    }

    @Override
    public String toString() {
        return "Work " + dayShiftType +  " last " + ShiftLastLength + " days";
    }

}
