
package org.optaplanner.examples.nurserostering.domain.pattern;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import org.optaplanner.examples.nurserostering.domain.ShiftType;

@XStreamAlias("ShiftAssignedSomeWeeksPattern")
public class ShiftAssignedSomeWeeksPattern extends Pattern{
		
	private ShiftType dayShiftType; 

    private int weekGapLength;

    public ShiftType getDayShiftType() {
        return dayShiftType;
    }

    public void setDayShiftType(ShiftType dayShiftType) {
        this.dayShiftType = dayShiftType;
    }

    public int getweekGapLength() {
        return weekGapLength;
    }

    public void setweekGapLength(int weekGapLength) {
        this.weekGapLength = weekGapLength;
    }

    @Override
    public String toString() {
        return "Work " + dayShiftType +  " better less than " + weekGapLength + " days";
    }

}
