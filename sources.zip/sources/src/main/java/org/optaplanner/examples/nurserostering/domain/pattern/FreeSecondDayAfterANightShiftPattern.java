package org.optaplanner.examples.nurserostering.domain.pattern;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import org.optaplanner.examples.nurserostering.domain.ShiftType;

@XStreamAlias("FreeSecondDayAfterANightShiftPattern")
public class FreeSecondDayAfterANightShiftPattern extends Pattern{
	
	    private ShiftType dayShiftType0;
	    private ShiftType dayShiftType1;
	    private ShiftType workShiftType;

	    public ShiftType getDayShiftType0() {
	        return dayShiftType0;
	    }

	    public void setDayShiftType0(ShiftType dayShiftType0) {
	        this.dayShiftType0 = dayShiftType0;
	    }
	    
	    public ShiftType getDayShiftType1() {
	        return dayShiftType1;
	    }

	    public void setDayShiftType1(ShiftType dayShiftType1) {
	        this.dayShiftType1 = dayShiftType1;
	    }
	    
	    public ShiftType getworkShiftType() {
	        return workShiftType;
	    }

	    public void setworkShiftType(ShiftType workShiftType) {
	        this.workShiftType = workShiftType;
	    }

	    @Override
	    public String toString() {
	    	return "Free on " + dayShiftType0 +dayShiftType0+ " followed by a work day of night shift or"+ workShiftType;
	    }

}
