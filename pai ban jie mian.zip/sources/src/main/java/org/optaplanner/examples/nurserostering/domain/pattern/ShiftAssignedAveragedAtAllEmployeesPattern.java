package org.optaplanner.examples.nurserostering.domain.pattern;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import org.optaplanner.examples.nurserostering.domain.ShiftType;

@XStreamAlias("ShiftAssignedAveragedAtAllEmployeesPattern")
public class ShiftAssignedAveragedAtAllEmployeesPattern extends Pattern {
	
    private ShiftType dayShiftType; 

    private int dayShiftLength;

    public ShiftType getDayShiftType() {
        return dayShiftType;
    }

    public void setDayShiftType(ShiftType dayShiftType) {
        this.dayShiftType = dayShiftType;
    }

    public int getdayShiftLength() {
        return dayShiftLength;
    }

    public void setdayShiftLength(int dayShiftLength) {
        this.dayShiftLength = dayShiftLength;
    }

    @Override
    public String toString() {
        return "Work " + dayShiftType +  " better less than " + dayShiftLength + " days";
    }

}
