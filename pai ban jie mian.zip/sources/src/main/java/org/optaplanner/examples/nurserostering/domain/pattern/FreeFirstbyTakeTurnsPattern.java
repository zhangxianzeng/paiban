package org.optaplanner.examples.nurserostering.domain.pattern;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("FreeFirstbyTakeTurnsPattern")
public class FreeFirstbyTakeTurnsPattern extends Pattern {
	
	    private String freeDaysLength;
	    private int workLength;

	    
	    public String getfreeDaysLength() {
	        return freeDaysLength;
	    }

	    public void setfreeDaysLength(String freeDaysLength) {
	        this.freeDaysLength = freeDaysLength;
	    }
	    
	    public int getworkLength() {
	        return workLength;
	    }

	    public void setvacationLength(int workLength) {
	        this.workLength = workLength;
	    }

	    @Override
	    public String toString() {
	        return "Work " + freeDaysLength +  "days and free " +workLength + " days";
	    }

}
