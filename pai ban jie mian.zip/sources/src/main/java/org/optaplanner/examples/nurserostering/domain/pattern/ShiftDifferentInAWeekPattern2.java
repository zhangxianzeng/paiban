package org.optaplanner.examples.nurserostering.domain.pattern;

import org.optaplanner.examples.nurserostering.domain.ShiftType;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("ShiftDifferentInAWeekPattern2")
public class ShiftDifferentInAWeekPattern2 extends Pattern {
	private ShiftType dayShiftType; 

	  


		

		public ShiftType getDayShiftType() {
		return dayShiftType;
	}






	public void setDayShiftType(ShiftType dayShiftType) {
		this.dayShiftType = dayShiftType;
	}






		@Override
	    public String toString() {
	    	return "Shift assigned different in a week"+dayShiftType;
	    }

}
