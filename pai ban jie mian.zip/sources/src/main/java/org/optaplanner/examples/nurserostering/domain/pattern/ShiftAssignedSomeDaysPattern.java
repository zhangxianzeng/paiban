
package org.optaplanner.examples.nurserostering.domain.pattern;

import com.thoughtworks.xstream.annotations.XStreamAlias;

import org.optaplanner.examples.nurserostering.domain.Employee;
import org.optaplanner.examples.nurserostering.domain.ShiftType;

@XStreamAlias("ShiftAssignedSomeDaysPattern")
public class ShiftAssignedSomeDaysPattern extends Pattern{
		
	private ShiftType dayShiftType; 

    private int dayGapLength;
   
   
    public ShiftType getDayShiftType() {
		return dayShiftType;
	}


	public void setDayShiftType(ShiftType dayShiftType) {
		this.dayShiftType = dayShiftType;
	}


	public int getDayGapLength() {
		return dayGapLength;
	}


	public void setDayGapLength(int dayGapLength) {
		this.dayGapLength = dayGapLength;
	}


	


	@Override
	public String toString() {
		return "ShiftAssignedSomeDaysPattern [dayShiftType=" + dayShiftType + ", dayGapLength=" + dayGapLength + "]";
	}


	

}
