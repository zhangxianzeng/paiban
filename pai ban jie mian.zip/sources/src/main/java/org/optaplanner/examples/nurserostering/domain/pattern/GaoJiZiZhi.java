package org.optaplanner.examples.nurserostering.domain.pattern;

import org.optaplanner.examples.nurserostering.domain.ShiftType;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("GaoJiZiZhi")
public class GaoJiZiZhi extends Pattern{
	private ShiftType dayShiftType; 
	private int number1; 
private String title1;
public ShiftType getDayShiftType() {
	return dayShiftType;
}
public void setDayShiftType(ShiftType dayShiftType) {
	this.dayShiftType = dayShiftType;
}
public int getNumber1() {
	return number1;
}
public void setNumber1(int number1) {
	this.number1 = number1;
}
public String getTitle1() {
	return title1;
}
public void setTitle1(String title1) {
	this.title1 = title1;
}
@Override
public String toString() {
    return "dayShiftType " + dayShiftType +  "number1 " +number1 + " title1"+title1;
}


}
