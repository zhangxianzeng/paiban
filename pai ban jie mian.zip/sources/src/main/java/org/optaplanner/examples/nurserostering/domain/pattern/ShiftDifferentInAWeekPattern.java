package org.optaplanner.examples.nurserostering.domain.pattern;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("ShiftDifferentInAWeekPattern")
public class ShiftDifferentInAWeekPattern extends Pattern {
	

	    @Override
	    public String toString() {
	    	return "Shift assigned different in a week";
	    }

}
