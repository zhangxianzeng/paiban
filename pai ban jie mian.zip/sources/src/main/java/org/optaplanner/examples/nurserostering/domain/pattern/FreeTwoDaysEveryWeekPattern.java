package org.optaplanner.examples.nurserostering.domain.pattern;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import org.optaplanner.examples.nurserostering.domain.ShiftType;

@XStreamAlias("FreeTwoDaysEveryWeekPattern")
public class FreeTwoDaysEveryWeekPattern extends Pattern {
	
	    private ShiftType dayShiftType;

	    private int workDayLength;
	    private int freeDayLength;

	    
	    public int getworkDayLength() {
	        return workDayLength;
	    }

	    public void setworkDayLength(int workDayLength) {
	        this.workDayLength = workDayLength;
	    }
	    
	    public int getfreeDayLength() {
	        return freeDayLength;
	    }

	    public void setfreeDayLength(int freeDayLength) {
	        this.freeDayLength = freeDayLength;
	    }

	    @Override
	    public String toString() {
	        return "Work " + workDayLength +  "days and free " +freeDayLength + " days";
	    }

}
