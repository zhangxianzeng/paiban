package org.optaplanner.examples.nurserostering.domain.pattern;

import com.thoughtworks.xstream.annotations.XStreamAlias;


@XStreamAlias("ShiftWorkNumberAssignedforPergnantPattern")
public class ShiftWorkNumberAssignedforPergnantPattern extends Pattern {
	
	    private int NumofWorkers;
	    
	    public int getNumofWorkers() {
	        return NumofWorkers;
	    }
	    public void setNumofWorkers(int NumofWorkers) {
	        this.NumofWorkers = NumofWorkers;
	    }
	    
	    @Override
	    public String toString() {
	    	return "shift assigned  more than" + NumofWorkers + " person";
	    }

}
