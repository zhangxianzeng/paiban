package org.optaplanner.examples.nurserostering.domain.pattern;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import org.optaplanner.examples.nurserostering.domain.ShiftType;

@XStreamAlias("FreeAfterANightShiftPattern")
public class FreeAfterANightShiftPattern extends Pattern {
	
	    private ShiftType dayShiftType;
	    
	    private ShiftType workShiftType;

	    public ShiftType getDayShiftType() {
	        return dayShiftType;
	    }

	    public void setDayShiftType(ShiftType dayShiftType) {
	        this.dayShiftType = dayShiftType;
	    }
	    
	    public ShiftType getworkShiftType() {
	        return workShiftType;
	    }

	    public void setworkShiftType(ShiftType workShiftType) {
	        this.workShiftType = workShiftType;
	    }

	    @Override
	    public String toString() {
	    	return "Free on " + dayShiftType + " followed by a work day of night shift or"+ workShiftType;
	    }

}
