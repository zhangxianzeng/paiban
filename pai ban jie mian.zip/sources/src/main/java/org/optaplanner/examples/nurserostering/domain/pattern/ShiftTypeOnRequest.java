package org.optaplanner.examples.nurserostering.domain.pattern;

import org.optaplanner.examples.nurserostering.domain.Employee;

import org.optaplanner.examples.nurserostering.domain.ShiftType;

import com.thoughtworks.xstream.annotations.XStreamAlias;
@XStreamAlias("ShiftTypeOnRequest")
public class ShiftTypeOnRequest extends Pattern{
	// private Employee employee;
	    private ShiftType shiftType;
	    private int weight;
//		public Employee getEmployee() {
//			return employee;
//		}
//		public void setEmployee(Employee employee) {
//			this.employee = employee;
//		}
		public ShiftType getShiftType() {
			return shiftType;
		}
		public void setShiftType(ShiftType shiftType) {
			this.shiftType = shiftType;
		}
		public int getWeight() {
			return weight;
		}
		public void setWeight(int weight) {
			this.weight = weight;
		}
		 @Override
		    public String toString() {
		        return shiftType + "_ON_" ;
		    }

}
