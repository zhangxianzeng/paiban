
package org.optaplanner.examples.nurserostering.domain.pattern;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import org.optaplanner.examples.nurserostering.domain.ShiftType;

@XStreamAlias("ShiftAssignedSomeWeeksPattern2")
public class ShiftAssignedSomeWeeksPattern2 extends Pattern{
		
	private ShiftType dayShiftType; 
	private ShiftType dayShiftType1; 
    private int weekGapLength;

    public ShiftType getDayShiftType() {
        return dayShiftType;
    }

    public ShiftType getDayShiftType1() {
		return dayShiftType1;
	}

	public void setDayShiftType1(ShiftType dayShiftType1) {
		this.dayShiftType1 = dayShiftType1;
	}

	public void setDayShiftType(ShiftType dayShiftType) {
        this.dayShiftType = dayShiftType;
    }

    public int getweekGapLength() {
        return weekGapLength;
    }

    public void setweekGapLength(int weekGapLength) {
        this.weekGapLength = weekGapLength;
    }

    @Override
    public String toString() {
        return "Work " + dayShiftType +  " better less than " + weekGapLength + " days"+dayShiftType+"better less than";
    }

}
